
var ctx = document.getElementById('myChart0').getContext('2d');
  var myChart = new Chart(ctx, config = {
      type: 'pie',
      data: {
          
          datasets: [{
              label: 'data',
              data: [12, 19, 15],
              backgroundColor: [
                "yellow",
                "green",
                "red",
              ],
              borderColor: [
                "yellow",
                "green",
                "red",
              ],

              borderWidth: 1
          }]
      },
      options: {
        animation:false,  
      }
      
  });  

  var xValues = ["data1", "data2", "data3", "data4", "data5", "data6", "data7", "data8", "data9", "data10"];
  var yValues = [12, 19, 30, 26, 65, 35, 84, 22, 12, 40];
  var barColors = ["red", "green","yellow"];
  var ctx = document.getElementById('myChart1').getContext('2d');
  var myChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: xValues,
      datasets: [{
        backgroundColor: barColors,
        data: yValues
      }]
    },
      options: {
        animation:false, 
        display: true,
        legend: {
          position: 'center',
        },
        scales: {
          x: {
            beginAtZero: true,
            stacked: true
          }
        } 
      } 
  }); 

function hide1() {
  console.log('Layout 01 screen');
};

function hide2() {
  console.log('Layout 02 screen');
};

var a = [];
var b = [];
var layout = [];
var listdata = [];

layout[0] = "Layout 1"; layout[1] = "Layout 2"; 

document.getElementById("input01").innerHTML = layout[0];
document.getElementById("input02").innerHTML = layout[1];

hide1();

function hide1() {
  listdata[0] = layout[0];
  b[0] = "A1"; b[1] = "A2"; b[2] = "A3"; b[3] = "A4"; b[4] = "A5";

input();

  document.getElementById("input01").innerHTML = listdata[0];
  console.log('Layout 01 screen');
};



//hide2();


function hide2() {
  listdata[1] = layout[1];
  b[0] = "k1"; b[1] = "k2"; b[2] = "k3"; b[3] = "k4"; b[4] = "k5";

  input();

  document.getElementById("input02").innerHTML = listdata[1];
  console.log('Layout 02 screen');
};



function input(){
  document.getElementById("input1").innerHTML = b[0];
  document.getElementById("input2").innerHTML = b[1];
  document.getElementById("input3").innerHTML = b[2];
}

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 30],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {}
});  

