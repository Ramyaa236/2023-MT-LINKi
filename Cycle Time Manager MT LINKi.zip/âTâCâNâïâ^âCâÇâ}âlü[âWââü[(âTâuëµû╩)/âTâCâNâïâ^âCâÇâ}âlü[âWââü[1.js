
var ctx = document.getElementById('myChart0').getContext('2d');
  var myChart = new Chart(ctx, config = {
      type: 'pie',
      data: {
          
          datasets: [{
              label: 'data',
              data: [20, 20, 20, 20, 20],
              backgroundColor: [
                "#fff33f",
                "#f39800",
                "#009e96",
                "salmon",
                "rgb(81, 221, 81)",
              ],
              borderColor: [
                "#fff33f",
                "#f39800",
                "#009e96",
                "salmon",
                "rgb(81, 221, 81)",
              ],

              borderWidth: 1
          }]
      },
      options: {
        animation:false,  
      }
      
  });  


function hide1() {
  console.log('Layout 01 screen');
};

function hide2() {
  console.log('Layout 02 screen');
};

var a = [];
var b = [];
var layout = [];
var listdata = [];

layout[0] = "Layout 1"; layout[1] = "Layout 2"; 

document.getElementById("input01").innerHTML = layout[0];
document.getElementById("input02").innerHTML = layout[1];

/*Edit input data from below*/

hide1();

function hide1() {
  listdata[0] = layout[0];
  a[0] = "OP10";
  b[0] = "A1"; b[1] = "A2"; b[2] = "A3";
input();

  document.getElementById("input01").innerHTML = listdata[0];
  console.log('Layout 01 screen');
};


function hide2() {
  listdata[1] = layout[1];
  a[0] = "OP110";
  b[0] = "k1"; b[1] = "k2"; b[2] = "k3";
input();

  document.getElementById("input02").innerHTML = listdata[1];
  console.log('Layout 02 screen');
};

function input(){
  document.getElementById("inputa").innerHTML = a[0];
  document.getElementById("input1").innerHTML = b[0];
  document.getElementById("input2").innerHTML = b[1];
  document.getElementById("input3").innerHTML = b[2];
}

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

  /*function hide1() {
  document.getElementById("input01").innerHTML = listdata[0];
};

function hide2() {
  document.getElementById("input02").innerHTML = listdata[1];
};

function hide3() {
  document.getElementById("input03").innerHTML = listdata[2];
};*/

/*function drawChart() {
    console.log(all[0]);//仮
      if(all[0] == 0){
        var ctx = document.getElementById("myChart").getContext('2d');
    myChart = new Chart(ctx, {
    type: 'pie',
    data: {
      datasets: [{
        backgroundColor: [
          "#a9a9a9",
        ],
        data: [1],
        borderWidth: 0,
      }]
    },
    options: {
      animation:false,
      maintainAspectRatio: false,
    }
    });
      }else{


      var ctx = document.getElementById('myChart').getContext('2d');
      myChart = new Chart(ctx, { // インスタンスをグローバル変数で生成
        type: 'pie',
    data: {
      datasets: [{
        backgroundColor: [
          "#fff33f",
          "#f39800",
          "#009e96",
          "red",
          "blue",
        ],
        data: [1, 1, 1, 1, 1]
      }]
    },
    options: {
      animation:false,
      maintainAspectRatio: false,
    }
    });
    
    }
   // }

   drawChart();*/