var ctx = document.getElementById('myChart1').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 30],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false,  
    }
    
});  


var ctx = document.getElementById('myChart2').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [18,56,77],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 


var ctx = document.getElementById('myChart3').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 30],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 
      
var ctx = document.getElementById('myChart4').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 77],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart5').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [22,45,67],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart6').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 66],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart7').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [10, 50,20],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart8').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 48, 30],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart9').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 69, 30],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 

var ctx = document.getElementById('myChart10').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [52, 19, 30],
            backgroundColor: [
              "yellow",
              "green",
              "red",
            ],
            borderColor: [
              "yellow",
              "green",
              "red",
            ],
            borderWidth: 1
        }]
    },
    options: {
      animation:false, 
    }
}); 


function hide1() {
  console.log('Layout 01 screen');
};

function hide2() {
  console.log('Layout 02 screen');
};

var a = [];
var b = [];
var layout = [];
var listdata = [];

layout[0] = "Layout 1"; layout[1] = "Layout 2"; 

document.getElementById("input01").innerHTML = layout[0];
document.getElementById("input02").innerHTML = layout[1];

hide1();

function hide1() {
  listdata[0] = layout[0];
  a[0] = "OP10"; a[1] = "OP20"; a[2] = "OP30"; a[3] = "OP40"; a[4] = "OP50"; 
  a[5] = "OP60"; a[6] = "OP70"; a[7] = "OP80"; a[8] = "OP90"; a[9] = "OP100"; 

  b[0] = "A1"; b[1] = "A2"; b[2] = "A3"; b[3] = "A4"; b[4] = "A5";
  b[5] = "B1"; b[6] = "B2"; b[7] = "B3"; b[8] = "B4"; b[9] = "B5";
  b[10] = "C1"; b[11] = "C2"; b[12] = "C3"; b[13] = "C4"; b[14] = "C5";
  b[15] = "D1"; b[16] = "D2"; b[17] = "D3"; b[18] = "D4"; b[19] = "D5";
  b[20] = "E1"; b[21] = "E2"; b[22] = "E3"; b[23] = "E4"; b[24] = "E5";
  b[25] = "F1"; b[26] = "F2"; b[27] = "F3"; b[28] = "F4"; b[29] = "F5";
  b[30] = "G1"; b[31] = "G2"; b[32] = "G3"; b[33] = "G4"; b[34] = "G5";
  b[35] = "H1"; b[36] = "H2"; b[37] = "H3"; b[38] = "H4"; b[39] = "H5";
  b[40] = "I1"; b[41] = "I2"; b[42] = "I3"; b[43] = "I4"; b[44] = "I5";
  b[45] = "J1"; b[46] = "J2"; b[47] = "J3"; b[48] = "J4"; b[49] = "J5";

input();

  document.getElementById("input01").innerHTML = listdata[0];
  console.log('Layout 01 screen');
};



//hide2();


function hide2() {
  listdata[1] = layout[1];
  a[0] = "OP110"; a[1] = "OP120"; a[2] = "OP130"; a[3] = "OP140"; a[4] = "OP150"; 
  a[5] = "OP160"; a[6] = "OP170"; a[7] = "OP180"; a[8] = "OP190"; a[9] = "OP200"; 

  b[0] = "k1"; b[1] = "k2"; b[2] = "k3"; b[3] = "k4"; b[4] = "k5";
  b[5] = "L1"; b[6] = "L2"; b[7] = "L3"; b[8] = "L4"; b[9] = "L5";
  b[10] = "M1"; b[11] = "M2"; b[12] = "M3"; b[13] = "M4"; b[14] = "M5";
  b[15] = "N1"; b[16] = "N2"; b[17] = "N3"; b[18] = "N4"; b[19] = "N5";
  b[20] = "O1"; b[21] = "O2"; b[22] = "O3"; b[23] = "O4"; b[24] = "O5";
  b[25] = "P1"; b[26] = "P2"; b[27] = "P3"; b[28] = "P4"; b[29] = "P5";
  b[30] = "Q1"; b[31] = "Q2"; b[32] = "Q3"; b[33] = "Q4"; b[34] = "Q5";
  b[35] = "R1"; b[36] = "R2"; b[37] = "R3"; b[38] = "R4"; b[39] = "R5";
  b[40] = "S1"; b[41] = "S2"; b[42] = "S3"; b[43] = "S4"; b[44] = "S5";
  b[45] = "T1"; b[46] = "T2"; b[47] = "T3"; b[48] = "T4"; b[49] = "T5";

  input();

  document.getElementById("input02").innerHTML = listdata[1];
  console.log('Layout 02 screen');
};



function input(){
  document.getElementById("inputa").innerHTML = a[0];
  document.getElementById("inputb").innerHTML = a[1];
  document.getElementById("inputc").innerHTML = a[2];
  document.getElementById("inputd").innerHTML = a[3];
  document.getElementById("inpute").innerHTML = a[4];
  document.getElementById("inputf").innerHTML = a[5];
  document.getElementById("inputg").innerHTML = a[6];
  document.getElementById("inputh").innerHTML = a[7];
  document.getElementById("inputi").innerHTML = a[8];
  document.getElementById("inputj").innerHTML = a[9];
  document.getElementById("input1").innerHTML = b[0];
  document.getElementById("input2").innerHTML = b[1];
  document.getElementById("input3").innerHTML = b[2];
  document.getElementById("input4").innerHTML = b[3];
  document.getElementById("input5").innerHTML = b[4];
  document.getElementById("input6").innerHTML = b[5];
  document.getElementById("input7").innerHTML = b[6];
  document.getElementById("input8").innerHTML = b[7];
  document.getElementById("input9").innerHTML = b[8];
  document.getElementById("input10").innerHTML = b[9];
  document.getElementById("input11").innerHTML = b[10];
  document.getElementById("input12").innerHTML = b[11];
  document.getElementById("input13").innerHTML = b[12];
  document.getElementById("input14").innerHTML = b[13];
  document.getElementById("input15").innerHTML = b[14];
  document.getElementById("input16").innerHTML = b[15];
  document.getElementById("input17").innerHTML = b[16];
  document.getElementById("input18").innerHTML = b[17];
  document.getElementById("input19").innerHTML = b[18];
  document.getElementById("input20").innerHTML = b[19];
  document.getElementById("input21").innerHTML = b[20];
  document.getElementById("input22").innerHTML = b[21];
  document.getElementById("input23").innerHTML = b[22];
  document.getElementById("input24").innerHTML = b[23];
  document.getElementById("input25").innerHTML = b[24];
  document.getElementById("input26").innerHTML = b[25];
  document.getElementById("input27").innerHTML = b[26];
  document.getElementById("input28").innerHTML = b[27];
  document.getElementById("input29").innerHTML = b[28];
  document.getElementById("input30").innerHTML = b[29];
  /*document.getElementById("input31").innerHTML = b[30];
  document.getElementById("input32").innerHTML = b[31];
  document.getElementById("input33").innerHTML = b[32];
  document.getElementById("input34").innerHTML = b[33];
  document.getElementById("input35").innerHTML = b[34];
  document.getElementById("input36").innerHTML = b[35];
  document.getElementById("input37").innerHTML = b[36];
  document.getElementById("input38").innerHTML = b[37];
  document.getElementById("input39").innerHTML = b[38];
  document.getElementById("input40").innerHTML = b[39];
  document.getElementById("input41").innerHTML = b[40];
  document.getElementById("input42").innerHTML = b[41];
  document.getElementById("input43").innerHTML = b[42];
  document.getElementById("input44").innerHTML = b[43];
  document.getElementById("input45").innerHTML = b[44];
  document.getElementById("input46").innerHTML = b[45];
  document.getElementById("input47").innerHTML = b[46];
  document.getElementById("input48").innerHTML = b[47];
  document.getElementById("input49").innerHTML = b[48];
  document.getElementById("input50").innerHTML = b[49];
  */
}

/*エラーが出るので一時的に非表示にしています
function layoutHandler(){
  var styleLink = document.getElementById("pagestyle");
  if(window.innerWidth < 900){
    styleLink.setAttribute("href", "mobile.css");
  } else if(window.innerWidth < 1200){
    styleLink.setAttribute("href", "medium.css");
  }else{
    styleLink.setAttribute("href", "large.css");
  }
}
window.onresize = layoutHandler;
layoutHandler();

*/

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

/*グラフを格納する場所がないため一時的に削除
var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        
        datasets: [{
            label: 'data',
            data: [12, 19, 30],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {}
});
*/  

document.getElementById('pagejump').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump1').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump1");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump2').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump2");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump3').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump3");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump4').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump4");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump5').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump5");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump6').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump6");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump7').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump7");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump8').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump8");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump9').onclick = function(){//サブ画面表示用
  var div = document.getElementById("pagejump9");
  console.log(div);
  var spans = div.getElementsByTagName("span");
  console.log(spans)
  var tabletext=spans[0]["outerText"];
  console.log(tabletext);
  window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}