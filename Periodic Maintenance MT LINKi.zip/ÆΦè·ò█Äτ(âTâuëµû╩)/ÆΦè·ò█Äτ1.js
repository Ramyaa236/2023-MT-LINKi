
var ctx = document.getElementById('myChart1').getContext('2d');
  var myChart = new Chart(ctx, config = {
      type: 'pie',
      data: {
          
          datasets: [{
              label: 'data',
              data: [12, 19, 30],
              backgroundColor: [
                "yellow",
                "green",
                "red",
              ],
              borderColor: [
                "yellow",
                "green",
                "red",
              ],

              borderWidth: 1
          }]
      },
      options: {
        animation:false,  
      }
      
  });  


function hide1() {
  console.log('Layout 01 screen');
};

function hide2() {
  console.log('Layout 02 screen');
};

var a = [];
var b = [];
var layout = [];
var listdata = [];

layout[0] = "Layout 1"; layout[1] = "Layout 2"; 

document.getElementById("input01").innerHTML = layout[0];
document.getElementById("input02").innerHTML = layout[1];

hide1();

function hide1() {
  listdata[0] = layout[0];
  a[0] = "OP10"; b[0] = "A1"; b[1] = "A2"; b[2] = "A3"; b[3] = "A4"; b[4] = "A5";

input();

  document.getElementById("input01").innerHTML = listdata[0];
  console.log('Layout 01 screen');
};



//hide2();


function hide2() {
  listdata[1] = layout[1];
  a[0] = "OP110"; b[0] = "k1"; b[1] = "k2"; b[2] = "k3"; b[3] = "k4"; b[4] = "k5";

  input();

  document.getElementById("input02").innerHTML = listdata[1];
  console.log('Layout 02 screen');
};



function input(){
  document.getElementById("inputa").innerHTML = a[0];
  document.getElementById("input1").innerHTML = b[0];
  document.getElementById("input2").innerHTML = b[1];
  document.getElementById("input3").innerHTML = b[2];
}


/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function equipmentdata1(){
  d=[];
  for(var i=0; i< equipments[0].length; i++){
    d[i] = equipments[0][i]['name']
  }
  document.getElementById("Select1").innerHTML = d[0];
  document.getElementById("Select2").innerHTML = d[1];
  document.getElementById("Select3").innerHTML = d[2];
  document.getElementById("Select4").innerHTML = d[3];
  document.getElementById("Select5").innerHTML = d[4];
  document.getElementById("Select6").innerHTML = d[5];
  document.getElementById("Select7").innerHTML = d[6];
  document.getElementById("Select8").innerHTML = d[7];
  document.getElementById("Select9").innerHTML = d[8];
  document.getElementById("Select10").innerHTML = d[9];
  document.getElementById("Select11").innerHTML = d[10];
  document.getElementById("Select12").innerHTML = d[11];
  document.getElementById("Select13").innerHTML = d[12];
  document.getElementById("Select14").innerHTML = d[13];
  document.getElementById("Select15").innerHTML = d[14];
  document.getElementById("Select16").innerHTML = d[15];
  document.getElementById("Select17").innerHTML = d[16];
  document.getElementById("Select18").innerHTML = d[17];
  document.getElementById("Select19").innerHTML = d[18];
  document.getElementById("Select20").innerHTML = d[19];
  document.getElementById("Select21").innerHTML = d[20];
  document.getElementById("Select22").innerHTML = d[21];
  document.getElementById("Select23").innerHTML = d[22];
  document.getElementById("Select24").innerHTML = d[23];
  document.getElementById("Select25").innerHTML = d[24];
  document.getElementById("Select26").innerHTML = d[25];
  document.getElementById("Select27").innerHTML = d[26];
  document.getElementById("Select28").innerHTML = d[27];
  document.getElementById("Select29").innerHTML = d[28];
  document.getElementById("Select30").innerHTML = d[29];
  document.getElementById("Select31").innerHTML = d[30];
  document.getElementById("Select32").innerHTML = d[31];
  document.getElementById("Select33").innerHTML = d[32];
  document.getElementById("Select34").innerHTML = d[33];
  document.getElementById("Select35").innerHTML = d[34];
}

function equipmentdata2(){
  d=[];
  for(var i=0; i< equipments[1].length; i++){
    d[i] = equipments[1][i]['name']
  }
  document.getElementById("Select1").innerHTML = d[0];
  document.getElementById("Select2").innerHTML = d[1];
  document.getElementById("Select3").innerHTML = d[2];
  document.getElementById("Select4").innerHTML = d[3];
  document.getElementById("Select5").innerHTML = d[4];
  document.getElementById("Select6").innerHTML = d[5];
  document.getElementById("Select7").innerHTML = d[6];
  document.getElementById("Select8").innerHTML = d[7];
  document.getElementById("Select9").innerHTML = d[8];
  document.getElementById("Select10").innerHTML = d[9];
  document.getElementById("Select11").innerHTML = d[10];
  document.getElementById("Select12").innerHTML = d[11];
  document.getElementById("Select13").innerHTML = d[12];
  document.getElementById("Select14").innerHTML = d[13];
  document.getElementById("Select15").innerHTML = d[14];
  document.getElementById("Select16").innerHTML = d[15];
  document.getElementById("Select17").innerHTML = d[16];
  document.getElementById("Select18").innerHTML = d[17];
  document.getElementById("Select19").innerHTML = d[18];
  document.getElementById("Select20").innerHTML = d[19];
  document.getElementById("Select21").innerHTML = d[20];
  document.getElementById("Select22").innerHTML = d[21];
  document.getElementById("Select23").innerHTML = d[22];
  document.getElementById("Select24").innerHTML = d[23];
  document.getElementById("Select25").innerHTML = d[24];
  document.getElementById("Select26").innerHTML = d[25];
  document.getElementById("Select27").innerHTML = d[26];
  document.getElementById("Select28").innerHTML = d[27];
  document.getElementById("Select29").innerHTML = d[28];
  document.getElementById("Select30").innerHTML = d[29];
  document.getElementById("Select31").innerHTML = d[30];
  document.getElementById("Select32").innerHTML = d[31];
  document.getElementById("Select33").innerHTML = d[32];
  document.getElementById("Select34").innerHTML = d[33];
  document.getElementById("Select35").innerHTML = d[34];
}




async function displaydata(){//ランキングのデータを表示する
  document.getElementById("input1").innerHTML = a[0];
  document.getElementById("input2").innerHTML = a[1];
  document.getElementById("input3").innerHTML = a[2];
  document.getElementById("input4").innerHTML = a[3];
  document.getElementById("input5").innerHTML = a[4];
  document.getElementById("input6").innerHTML = a[5];
  document.getElementById("input7").innerHTML = a[6];
  document.getElementById("input8").innerHTML = a[7];
  document.getElementById("input9").innerHTML = a[8];
  document.getElementById("input10").innerHTML = a[9];
  document.getElementById("input11").innerHTML = a[10];
  document.getElementById("input12").innerHTML = a[11];
  document.getElementById("input13").innerHTML = a[12];
  document.getElementById("input14").innerHTML = a[13];
  document.getElementById("input15").innerHTML = a[14];
  document.getElementById("input16").innerHTML = a[15];
  document.getElementById("input17").innerHTML = a[16];
  document.getElementById("input18").innerHTML = a[17];
  document.getElementById("input19").innerHTML = a[18];
  document.getElementById("input20").innerHTML = a[19];
  document.getElementById("input21").innerHTML = a[20];
  document.getElementById("input22").innerHTML = a[21];
  document.getElementById("input23").innerHTML = a[22];
  document.getElementById("input24").innerHTML = a[23];
  document.getElementById("input25").innerHTML = a[24];
  document.getElementById("input26").innerHTML = a[25];
  document.getElementById("input27").innerHTML = a[26];
  document.getElementById("input28").innerHTML = a[27];
  document.getElementById("input29").innerHTML = a[28];
  document.getElementById("input30").innerHTML = a[29];
  document.getElememtById("input31").innerHTML = a[30];
  document.getElementById("input32").innerHTML = a[31];
  document.getElementById("input33").innerHTML = a[32];
  document.getElementById("input34").innerHTML = a[33];
  document.getElementById("input35").innerHTML = a[34];

  document.getElementById("inputA1").innerHTML = b[0];
  document.getElementById("inputA2").innerHTML = b[1];
  document.getElementById("inputA3").innerHTML = b[2];
  document.getElementById("inputA4").innerHTML = b[3];
  document.getElementById("inputA5").innerHTML = b[4];
  document.getElementById("inputA6").innerHTML = b[5];
  document.getElementById("inputA7").innerHTML = b[6];
  document.getElementById("inputA8").innerHTML = b[7];
  document.getElementById("inputA9").innerHTML = b[8];
  document.getElementById("inputA10").innerHTML = b[9];
  document.getElementById("inputA11").innerHTML = b[10];
  document.getElementById("inputA12").innerHTML = b[11];
  document.getElementById("inputA13").innerHTML = b[12];
  document.getElementById("inputA14").innerHTML = b[13];
  document.getElementById("inputA15").innerHTML = b[14];
  document.getElementById("inputA16").innerHTML = b[15];
  document.getElementById("inputA17").innerHTML = b[16];
  document.getElementById("inputA18").innerHTML = b[17];
  document.getElementById("inputA19").innerHTML = b[18];
  document.getElementById("inputA20").innerHTML = b[19];
  document.getElementById("inputA21").innerHTML = b[20];
  document.getElementById("inputA22").innerHTML = b[21];
  document.getElementById("inputA23").innerHTML = b[22];
  document.getElementById("inputA24").innerHTML = b[23];
  document.getElementById("inputA25").innerHTML = b[24];
  document.getElementById("inputA26").innerHTML = b[25];
  document.getElementById("inputA27").innerHTML = b[26];
  document.getElementById("inputA28").innerHTML = b[27];
  document.getElementById("inputA29").innerHTML = b[28];
  document.getElementById("inputA30").innerHTML = b[29];
  document.getElementById("inputA31").innerHTML = b[30];
  document.getElementById("inputA32").innerHTML = b[31];
  document.getElementById("inputA33").innerHTML = b[32];
  document.getElementById("inputA34").innerHTML = b[33];
  document.getElementById("inputA35").innerHTML = b[34];


  document.getElementById("inputB1").innerHTML = c[0];
  document.getElementById("inputB2").innerHTML = c[1];
  document.getElementById("inputB3").innerHTML = c[2];
  document.getElementById("inputB4").innerHTML = c[3];
  document.getElementById("inputB5").innerHTML = c[4];
  document.getElementById("inputB6").innerHTML = c[5];
  document.getElementById("inputB7").innerHTML = c[6];
  document.getElementById("inputB8").innerHTML = c[7];
  document.getElementById("inputB9").innerHTML = c[8];
  document.getElementById("inputB10").innerHTML = c[9];
  document.getElementById("inputB11").innerHTML = c[10];
  document.getElementById("inputB12").innerHTML = c[11];
  document.getElementById("inputB13").innerHTML = c[12];
  document.getElementById("inputB14").innerHTML = c[13];
  document.getElementById("inputB15").innerHTML = c[14];
  document.getElementById("inputB16").innerHTML = c[15];
  document.getElementById("inputB17").innerHTML = c[16];
  document.getElementById("inputB18").innerHTML = c[17];
  document.getElementById("inputB19").innerHTML = c[18];
  document.getElementById("inputB20").innerHTML = c[19];  
  document.getElementById("inputB21").innerHTML = c[20];
  document.getElementById("inputB22").innerHTML = c[21];
  document.getElementById("inputB23").innerHTML = c[22];
  document.getElementById("inputB24").innerHTML = c[23];
  document.getElementById("inputB25").innerHTML = c[24];
  document.getElementById("inputB26").innerHTML = c[25];
  document.getElementById("inputB27").innerHTML = c[26];
  document.getElementById("inputB28").innerHTML = c[27];
  document.getElementById("inputB29").innerHTML = c[28];
  document.getElementById("inputB30").innerHTML = c[29];
  document.getElementById("inputB31").innerHTML = c[30];
  document.getElementById("inputB32").innerHTML = c[31];
  document.getElementById("inputB33").innerHTML = c[32];
  document.getElementById("inputB34").innerHTML = c[33];
  document.getElementById("inputB35").innerHTML = c[34];


  document.getElementById("inputC1").innerHTML = d[0];
  document.getElementById("inputC2").innerHTML = d[1];
  document.getElementById("inputC3").innerHTML = d[2];
  document.getElementById("inputC4").innerHTML = d[3];
  document.getElementById("inputC5").innerHTML = d[4];
  document.getElementById("inputC6").innerHTML = d[5];
  document.getElementById("inputC7").innerHTML = d[6];
  document.getElementById("inputC8").innerHTML = d[7];
  document.getElementById("inputC9").innerHTML = d[8];
  document.getElementById("inputC10").innerHTML = d[9];
  document.getElementById("inputC11").innerHTML = d[10];
  document.getElementById("inputC12").innerHTML = d[11];
  document.getElementById("inputC13").innerHTML = d[12];
  document.getElementById("inputC14").innerHTML = d[13];
  document.getElementById("inputC15").innerHTML = d[14];
  document.getElementById("inputC16").innerHTML = d[15];
  document.getElementById("inputC17").innerHTML = d[16];
  document.getElementById("inputC18").innerHTML = d[17];
  document.getElementById("inputC19").innerHTML = d[18];
  document.getElementById("inputC20").innerHTML = d[19];  
  document.getElementById("inputC21").innerHTML = d[20];
  document.getElementById("inputC22").innerHTML = d[21];
  document.getElementById("inputC23").innerHTML = d[22];
  document.getElementById("inputC24").innerHTML = d[23];
  document.getElementById("inputC25").innerHTML = d[24];
  document.getElementById("inputC26").innerHTML = d[25];
  document.getElementById("inputC27").innerHTML = d[26];
  document.getElementById("inputC28").innerHTML = d[27];
  document.getElementById("inputC29").innerHTML = d[28];
  document.getElementById("inputC30").innerHTML = d[29];
  document.getElementById("inputC31").innerHTML = d[30];
  document.getElementById("inputC32").innerHTML = d[31];
  document.getElementById("inputC33").innerHTML = d[32];
  document.getElementById("inputC34").innerHTML = d[33];
  document.getElementById("inputC35").innerHTML = d[34];


  document.getElementById("inputD1").innerHTML = e[0];
  document.getElementById("inputD2").innerHTML = e[1];
  document.getElementById("inputD3").innerHTML = e[2];
  document.getElementById("inputD4").innerHTML = e[3];
  document.getElementById("inputD5").innerHTML = e[4];
  document.getElementById("inputD6").innerHTML = e[5];
  document.getElementById("inputD7").innerHTML = e[6];
  document.getElementById("inputD8").innerHTML = e[7];
  document.getElementById("inputD9").innerHTML = e[8];
  document.getElementById("inputD10").innerHTML = e[9];
  document.getElementById("inputD11").innerHTML = e[10];
  document.getElementById("inputD12").innerHTML = e[11];
  document.getElementById("inputD13").innerHTML = e[12];
  document.getElementById("inputD14").innerHTML = e[13];
  document.getElementById("inputD15").innerHTML = e[14];
  document.getElementById("inputD16").innerHTML = e[15];
  document.getElementById("inputD17").innerHTML = e[16];
  document.getElementById("inputD18").innerHTML = e[17];
  document.getElementById("inputD19").innerHTML = e[18];
  document.getElementById("inputD20").innerHTML = e[19];  
  document.getElementById("inputD21").innerHTML = e[20];
  document.getElementById("inputD22").innerHTML = e[21];
  document.getElementById("inputD23").innerHTML = e[22];
  document.getElementById("inputD24").innerHTML = e[23];
  document.getElementById("inputD25").innerHTML = e[24];
  document.getElementById("inputD26").innerHTML = e[25];
  document.getElementById("inputD27").innerHTML = e[26];
  document.getElementById("inputD28").innerHTML = e[27];
  document.getElementById("inputD29").innerHTML = e[28];
  document.getElementById("inputD30").innerHTML = e[29];
  document.getElementById("inputD31").innerHTML = e[30];
  document.getElementById("inputD32").innerHTML = e[31];
  document.getElementById("inputD33").innerHTML = e[32];
  document.getElementById("inputD34").innerHTML = e[33];
  document.getElementById("inputD35").innerHTML = e[34];


  document.getElementById("inputE1").innerHTML = f[0];
  document.getElementById("inputE2").innerHTML = f[1];
  document.getElementById("inputE3").innerHTML = f[2];
  document.getElementById("inputE4").innerHTML = f[3];
  document.getElementById("inputE5").innerHTML = f[4];
  document.getElementById("inputE6").innerHTML = f[5];
  document.getElementById("inputE7").innerHTML = f[6];
  document.getElementById("inputE8").innerHTML = f[7];
  document.getElementById("inputE9").innerHTML = f[8];
  document.getElementById("inputE10").innerHTML = f[9];
  document.getElementById("inputE11").innerHTML = f[10];
  document.getElementById("inputE12").innerHTML = f[11];
  document.getElementById("inputE13").innerHTML = f[12];
  document.getElementById("inputE14").innerHTML = f[13];
  document.getElementById("inputE15").innerHTML = f[14];
  document.getElementById("inputE16").innerHTML = f[15];
  document.getElementById("inputE17").innerHTML = f[16];
  document.getElementById("inputE18").innerHTML = f[17];
  document.getElementById("inputE19").innerHTML = f[18];
  document.getElementById("inputE20").innerHTML = f[19];  
  document.getElementById("inputE21").innerHTML = f[20];
  document.getElementById("inputE22").innerHTML = f[21];
  document.getElementById("inputE23").innerHTML = f[22];
  document.getElementById("inputE24").innerHTML = f[23];
  document.getElementById("inputE25").innerHTML = f[24];
  document.getElementById("inputE26").innerHTML = f[25];
  document.getElementById("inputE27").innerHTML = f[26];
  document.getElementById("inputE28").innerHTML = f[27];
  document.getElementById("inputE29").innerHTML = f[28];
  document.getElementById("inputE30").innerHTML = f[29];
  document.getElementById("inputE31").innerHTML = f[30];
  document.getElementById("inputE32").innerHTML = f[31];
  document.getElementById("inputE33").innerHTML = f[32];
  document.getElementById("inputE34").innerHTML = f[33];
  document.getElementById("inputE35").innerHTML = f[34];
}
  /*function hide1() {
  document.getElementById("input01").innerHTML = listdata[0];
};

function hide2() {
  document.getElementById("input02").innerHTML = listdata[1];
};

function hide3() {
  document.getElementById("input03").innerHTML = listdata[2];
};*/

/*function drawChart() {
    console.log(all[0]);//仮
      if(all[0] == 0){
        var ctx = document.getElementById("myChart").getContext('2d');
    myChart = new Chart(ctx, {
    type: 'pie',
    data: {
      datasets: [{
        backgroundColor: [
          "#a9a9a9",
        ],
        data: [1],
        borderWidth: 0,
      }]
    },
    options: {
      animation:false,
      maintainAspectRatio: false,
    }
    });
      }else{


      var ctx = document.getElementById('myChart').getContext('2d');
      myChart = new Chart(ctx, { // インスタンスをグローバル変数で生成
        type: 'pie',
    data: {
      datasets: [{
        backgroundColor: [
          "#fff33f",
          "#f39800",
          "#009e96",
          "red",
          "blue",
        ],
        data: [1, 1, 1, 1, 1]
      }]
    },
    options: {
      animation:false,
      maintainAspectRatio: false,
    }
    });
    
    }
   // }

   drawChart();*/