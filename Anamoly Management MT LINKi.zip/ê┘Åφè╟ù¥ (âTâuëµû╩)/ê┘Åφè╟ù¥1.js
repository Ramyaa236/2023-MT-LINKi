
function hide1() {
  console.log('Layout 01 screen');
};

function hide2() {
  console.log('Layout 02 screen');
};

/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function myFunction1() {
  var dropdown1 = document.getElementById("myDropdown1");
  if (dropdown1.style.display === "block") {
    dropdown1.style.display = "none";
  } else {
    dropdown1.style.display = "block";
  }
}

window.onload = function() {
  var table = document.getElementById("myTable");
  var dropdown1 = document.getElementById("myDropdown1");
  
  // Remove any existing dropdown options
  dropdown1.innerHTML = "";
  
  // Retrieve table rows (excluding the header)
  var rows = table.getElementsByTagName("tr");
  for (var i = 1; i < rows.length; i++) {
    var item = rows[i].getElementsByTagName("td")[0].textContent;
    var option = document.createElement("a");
    option.href = "#";
    option.textContent = item;
    dropdown1.appendChild(option);
  }
}

var query = location.search;
var value = query.split('=');
 
console.log(decodeURIComponent(value[1]));

var Alldata =[];//すべてのアラームデータ
var group = [];//グループの取得
var equipments = [];////各グループに何種類の機械があるか
var machineAlarm = [];//機番ごとに分けたデータ
var subAlarmdata = [];//message、numberのみ
var Alarmdata = [];//machineName、message、numberのみ
var countdata = [];//アラームの回数を格納する。
var number = 1000;//データを1000個ずつで分割する
var separesult = [];//分割されたデータを格納する
let urlA = '192.168.1.203:3000';
var count = {};//メッセージの回数を数える

var a = [];
var b = [];
var layout = [];
var listdata = [];

//更新ボタンを押したときの期間(年月日時分秒)を格納する
var ymdlate;
var ymdlateSP;
var hmslate;
var hmslateSP;
var ymdnow;
var ymdnowSP;
var hmsnow;
var hmsnowSP;

var n = 365;//現在時刻から何日前のデータを取得するかを決める変数(デフォルトは1年分)；
var m = 9;//協定世界時からの時差を決める変数(日本は+9時間)

let day = new Date();//日付データ取得
day.setUTCHours(day.getUTCHours()+m);
var year = day.getUTCFullYear();
var month = ('0'+(day.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date = ('0'+day.getUTCDate()).slice(-2);
var hour = ('0'+(day.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min = ('0'+day.getUTCMinutes()).slice(-2);
var sec = ('0'+day.getSeconds()).slice(-2);

let dayuni = new Date();//世界標準時を取得
var yearuni = dayuni.getUTCFullYear();
var monthuni = ('0'+(dayuni.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var dateuni = ('0'+dayuni.getUTCDate()).slice(-2);
var houruni = ('0'+(dayuni.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var minuni = ('0'+dayuni.getUTCMinutes()).slice(-2);
var secuni = ('0'+dayuni.getSeconds()).slice(-2);


let day2 = new Date();//n日前の日付データ取得
day2.setUTCDate(day2.getUTCDate()-n);
day2.setUTCHours(day2.getUTCHours()+m);//日本の協定世界時からの時差は+9時間
var year7 = day2.getUTCFullYear();
var month7 = ('0'+(day2.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date7 = ('0'+day2.getUTCDate()).slice(-2);
var hour7 = ('0'+(day2.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min7 = ('0'+day2.getUTCMinutes()).slice(-2);
var sec7 = ('0'+day2.getSeconds()).slice(-2);

let day2uni = new Date();//n日前の日付データ取得(世界標準時)
day2uni.setUTCDate(day2uni.getUTCDate()-n);
var year7uni = day2uni.getUTCFullYear();
var month7uni = ('0'+(day2uni.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date7uni = ('0'+day2uni.getUTCDate()).slice(-2);
var hour7uni = ('0'+(day2uni.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min7uni = ('0'+day2uni.getUTCMinutes()).slice(-2);
var sec7uni = ('0'+day2uni.getSeconds()).slice(-2);

var realtime = yearuni+'-'+monthuni+'-'+dateuni+'T'+houruni+':'+minuni+':'+secuni+'Z';
var beforetime = year7uni+'-'+month7uni+'-'+date7uni+'T'+hour7uni+':'+min7uni+':'+sec7uni+'Z';
var realtimea = year+'-'+month+'-'+date+'T'+hour+':'+min+':'+sec+'Z';
var beforetimea = year7+'-'+month7+'-'+date7+'T'+hour7+':'+min7+':'+sec7+'Z';
console.log(realtime);
console.log(beforetime);
console.log(realtimea);
console.log(beforetimea);

/*document.getElementById("inputymd-7day").value =year7+'-'+month7+'-'+date7;
document.getElementById("inputymd").value =year+'-'+month+'-'+date;
document.getElementById("inputhms").value =hour7+':'+min7+':'+sec7;
document.getElementById("inputhms1").value =hour+':'+min+':'+sec;*/


document.getElementById("開始日").value =year7+'-'+month7+'-'+date7;
document.getElementById("終了日").value =year+'-'+month+'-'+date;
document.getElementById("開始時刻").value =hour7+':'+min7+':'+sec7;
document.getElementById("終了時刻").value =hour+':'+min+':'+sec;


async function Load(){//すべてのアラームデータを呼び出す
	const response = await fetch('http://'+urlA+'/api/v1/equipment/alarm-logs?from='+beforetime+'&to='+realtime+'&type=OPR');
	const data = await response.json(response);
	Alldata = data;
	return Alldata;
}

async function equipmentRF(){//各グループに何種類の機械があるかを調べる
  for(var i=0; i<group.length; i++){
      const response = await fetch('http://'+urlA+'/api/v1/groups/'+group[i]['name']+'/equipment');
      const data = await response.json(response);
      equipments[i] = data;
  }
  return equipments;
}

async function machineAlarmRF(){
  const response = await fetch('http://'+urlA+'/api/v1/equipment/alarm-logs?from='+beforetime+'&to='+realtime+'&equipment='+(decodeURIComponent(value[1]))+'&type=OPR');
  const data = await response.json(response);
  machineAlarm = data;
  return machineAlarm;
}

async function subAlarmdataRF(){
  for(var i=0; i<machineAlarm.length; i++){
    subAlarmdata[i]={message:machineAlarm[i]["message"],number:machineAlarm[i]["number"]};
  }
}

async function AlarmdataRF(){
  for(var i=0; i<machineAlarm.length; i++){
    if(machineAlarm[i]["message"] == '' && machineAlarm[i]["number"] != 0){//messageの中身が「''」だった場合、numberを元にmessageを補完する。尚、messageの中身が「''」でnummberが0の時は無視する
      var subAlarmdata_find = subAlarmdata.find(function(value) {
        return value.number == machineAlarm[i]["number"];
      })
      Alarmdata[i]={machineName:machineAlarm[i]["machineName"],message:subAlarmdata_find["message"],number:machineAlarm[i]["number"]};
    }else{
      Alarmdata[i]={machineName:machineAlarm[i]["machineName"],message:machineAlarm[i]["message"],number:machineAlarm[i]["number"]};
    } 
  }
}

async function CountdataRF(){
  for(var i=0; i<Alarmdata.length; i++){           
    var elm = Alarmdata[i]['message'];
    count[elm] = (count[elm] || 0) + 1;
  }
  var count_keys = Object.keys(count);
  var count_values = Object.values(count);
  for(var j=0; j<count_keys.length; j++){
    countdata[j]=[count_keys[j],count_values[j]];
  }
}

async function SortdataRF(){
  for(var i=0; i<countdata.length; i++){           
    if(countdata[i].length !== ""){//countdataの中身が空だった場合にエラーが出ないようにするための対策
        countdata.sort(function (a,b){
            return b[1] - a[1];
        });
    }
  }
}

/*async function makealarmdataRF(){
  for(var i=0; i<machineAlarm.length; i++){//各機番ごとのアラームデータのみの配列を作る
      Alarmkinds[i] = [];
      for(var j=0; j<machineAlarm[i].length; j++){
          Alarmkinds[i][j] = [];
          for(var k=0; k<machineAlarm[i][j].length; k++){
              Alarmkinds[i][j][k] = machineAlarm[i][j][k]['message'];
          }
      }
  }
}*/

async function runAll(){//すべてのﾌﾟﾛｸﾞﾗﾑを実行する
  const res1 = await Load();
  const res2 = await equipmentRF(res1);
  const res3 = await machineAlarmRF(res2);
  const res4 = await subAlarmdataRF(res3);
  const res5 = await AlarmdataRF(res4);
  const res6 = await CountdataRF(res5);
  const res7 = await SortdataRF(res6);
  console.log(countdata);     
}

async function displaycountdata(){//回数順のランキングを表示する
  a=[];
  b=[];
  c=[];  
  for(var i=0; i<countdata.length; i++){
    a[i] = displaycount[i][0];
    b[i] = displaycount[i][1];
    c[i] = displaycount[i][2];    
  }
//  console.log(a); 
//  console.log(b);
//  console.log(c);   
  displaydata();
}

async function displaytimedata(){//回数順のランキングを表示する
  a=[];
  b=[];
  c=[];  
  for(var i=0; i<countdata.length; i++){
    a[i] = displaytime[i][0];
    b[i] = displaytime[i][1];
    c[i] = displaytime[i][2];    
  }
//  console.log(a); 
//  console.log(b);
//  console.log(c);   
  displaydata();
}

function equipmentdata1(){
  d=[];
  for(var i=0; i< equipments[0].length; i++){
    d[i] = equipments[0][i]['name']
  }
  document.getElementById("Select1").innerHTML = d[0];
  document.getElementById("Select2").innerHTML = d[1];
  document.getElementById("Select3").innerHTML = d[2];
  document.getElementById("Select4").innerHTML = d[3];
  document.getElementById("Select5").innerHTML = d[4];
  document.getElementById("Select6").innerHTML = d[5];
  document.getElementById("Select7").innerHTML = d[6];
  document.getElementById("Select8").innerHTML = d[7];
  document.getElementById("Select9").innerHTML = d[8];
  document.getElementById("Select10").innerHTML = d[9];
  document.getElementById("Select11").innerHTML = d[10];
  document.getElementById("Select12").innerHTML = d[11];
  document.getElementById("Select13").innerHTML = d[12];
  document.getElementById("Select14").innerHTML = d[13];
  document.getElementById("Select15").innerHTML = d[14];
}

function equipmentdata2(){
  d=[];
  for(var i=0; i< equipments[1].length; i++){
    d[i] = equipments[1][i]['name']
  }
  document.getElementById("Select1").innerHTML = d[0];
  document.getElementById("Select2").innerHTML = d[1];
  document.getElementById("Select3").innerHTML = d[2];
  document.getElementById("Select4").innerHTML = d[3];
  document.getElementById("Select5").innerHTML = d[4];
  document.getElementById("Select6").innerHTML = d[5];
  document.getElementById("Select7").innerHTML = d[6];
  document.getElementById("Select8").innerHTML = d[7];
  document.getElementById("Select9").innerHTML = d[8];
  document.getElementById("Select10").innerHTML = d[9];
  document.getElementById("Select11").innerHTML = d[10];
  document.getElementById("Select12").innerHTML = d[11];
  document.getElementById("Select13").innerHTML = d[12];
  document.getElementById("Select14").innerHTML = d[13];
  document.getElementById("Select15").innerHTML = d[14];
}

async function groupRF (){//グループの種類を調べる
  const response = await fetch('http://'+urlA+'/api/v1/groups');
  const data = await response.json(response);
  group = data;
  return group;
}

async function groupinput(){//グループの表示を行う
  listdata[0] = group[0]['displayName'];
  listdata[1] = group[1]['displayName'];
  document.getElementById("input01").innerHTML = listdata[0];
  document.getElementById("input02").innerHTML = listdata[1];
}

async function rungroup(){//グループの読みだしと表示
  const res1 = await groupRF();
  const res2 = await groupinput(res1);
  console.log(group);
}

async function displaydata(){//ランキングのデータを表示する
  document.getElementById("input1").innerHTML = a[0];
  document.getElementById("input2").innerHTML = a[1];
  document.getElementById("input3").innerHTML = a[2];
  document.getElementById("input4").innerHTML = a[3];
  document.getElementById("input5").innerHTML = a[4];
  document.getElementById("input6").innerHTML = a[5];
  document.getElementById("input7").innerHTML = a[6];
  document.getElementById("input8").innerHTML = a[7];
  document.getElementById("input9").innerHTML = a[8];
  document.getElementById("input10").innerHTML = a[9];
  document.getElementById("input11").innerHTML = a[10];
  document.getElementById("input12").innerHTML = a[11];
  document.getElementById("input13").innerHTML = a[12];
  document.getElementById("input14").innerHTML = a[13];
  document.getElementById("input15").innerHTML = a[14];
  document.getElementById("input16").innerHTML = a[15];
  document.getElementById("input17").innerHTML = a[16];
  document.getElementById("input18").innerHTML = a[17];
  document.getElementById("input19").innerHTML = a[18];
  document.getElementById("input20").innerHTML = a[19];

  document.getElementById("inputAA").innerHTML = b[0];
  document.getElementById("inputAB").innerHTML = b[1];
  document.getElementById("inputAC").innerHTML = b[2];
  document.getElementById("inputAD").innerHTML = b[3];
  document.getElementById("inputAE").innerHTML = b[4];
  document.getElementById("inputAF").innerHTML = b[5];
  document.getElementById("inputAG").innerHTML = b[6];
  document.getElementById("inputAH").innerHTML = b[7];
  document.getElementById("inputAI").innerHTML = b[8];
  document.getElementById("inputAJ").innerHTML = b[9];
  document.getElementById("inputAK").innerHTML = b[10];
  document.getElementById("inputAL").innerHTML = b[11];
  document.getElementById("inputAM").innerHTML = b[12];
  document.getElementById("inputAN").innerHTML = b[13];
  document.getElementById("inputAO").innerHTML = b[14];
  document.getElementById("inputAP").innerHTML = b[15];
  document.getElementById("inputAQ").innerHTML = b[16];
  document.getElementById("inputAR").innerHTML = b[17];
  document.getElementById("inputAS").innerHTML = b[18];
  document.getElementById("inputAT").innerHTML = b[19];

  document.getElementById("inputBA").innerHTML = c[0];
  document.getElementById("inputBB").innerHTML = c[1];
  document.getElementById("inputBC").innerHTML = c[2];
  document.getElementById("inputBD").innerHTML = c[3];
  document.getElementById("inputBE").innerHTML = c[4];
  document.getElementById("inputBF").innerHTML = c[5];
  document.getElementById("inputBG").innerHTML = c[6];
  document.getElementById("inputBH").innerHTML = c[7];
  document.getElementById("inputBI").innerHTML = c[8];
  document.getElementById("inputBJ").innerHTML = c[9];
  document.getElementById("inputBK").innerHTML = c[10];
  document.getElementById("inputBL").innerHTML = c[11];
  document.getElementById("inputBM").innerHTML = c[12];
  document.getElementById("inputBN").innerHTML = c[13];
  document.getElementById("inputBO").innerHTML = c[14];
  document.getElementById("inputBP").innerHTML = c[15];
  document.getElementById("inputBQ").innerHTML = c[16];
  document.getElementById("inputBR").innerHTML = c[17];
  document.getElementById("inputBS").innerHTML = c[18];
  document.getElementById("inputBT").innerHTML = c[19];  
}


All();

var Alarmkinds = [];

async function makealarmdataRF(){//アラームメッセージのみのデータを作成
  for(var i=0; i<machineAlarm.length; i++){
    Alarmkinds[i] = machineAlarm[i]['message'];
  }
}

var Alarmkindsdata = [];

async function SearchalarmRF(){//アラームの種類を調べる
  for(var j=0; j<Alarmkinds.length; j++){
    Alarmkindsdata = Alarmkinds.filter(function (x, i, self){
      return self.indexOf(x) === i;
    });
  }
}

var Alarmtime = [];

async function makeAlaemtimeRF(){//アラームの種類ごとにデータをまとめる
  for(var i=0; i<Alarmkindsdata.length; i++){
    Alarmtime[i] = [];
    m=0;
    for(var j=0; j<machineAlarm.length; j++){
      if(Alarmkindsdata[i] == machineAlarm[j]['message']){
        Alarmtime[i][m] = machineAlarm[j];
        m=m+1;
      }
    }
  }
  console.log(Alarmtime);
}

 var totaltime = [];
 var total = 0;

async function TotaltimeRF(){//アラームごとの時間を計算する
  for(var i=0; i<Alarmtime.length; i++){
    totaltime[i] = [];
    for(var j=0; j<Alarmtime[i].length; j++){
      if(Alarmtime[i][j]['end'] == null){
        var s = 0;
      }else{
        var starttime = Date.parse(Alarmtime[i][j]['start']);
        var endtime = Date.parse(Alarmtime[i][j]['end']);
        var ms = endtime - starttime;
        var s = ms/1000;
        total = total + s;
      }
      var Messagetime = Alarmtime[i][j]['message'];
    }
    totaltime[i] = [Messagetime,total];
    total = 0;
  }
}

async function SorttotaltimeRF(){//アラームの時間が長い順に並び変える
  for(var i=0; i<totaltime.length; i++){           
    if(totaltime.length !== ""){//totaldataの中身が空だった場合にエラーが出ないようにするための対策
        totaltime.sort(function (a,b){
            return b[1] - a[1];
        });
    }
  }
  console.log(totaltime);
}

var displaycount = [];

async function displaycountRF(){//アラームの回数順のデータを表示する
  for(var i=0; i<totaltime.length; i++){
    for(var j=0; j<countdata.length; j++){
      if(totaltime[i][0] == countdata[j][0]){
        displaycount[j] = countdata[j].concat(totaltime[i][1]);
      }
    }
  }
  displaycountdata()
}

var displaytime = [];

async function displaytimeRF(){//アラームの時間順のデータを表示する
  for(var i=0; i<countdata.length; i++){
    for(var j=0; j<totaltime.length; j++){
      if(countdata[i][0] == totaltime[j][0]){
        displaytime[j] = [totaltime[j][0],countdata[i][1],totaltime[j][1]];
      }
    }
  }
  displaytimedata()
}

async function runAllTime(){
  const res1 = await makealarmdataRF();
  const res2 = await SearchalarmRF(res1);
  const res3 = await makeAlaemtimeRF(res2);
  const res4 = await TotaltimeRF(res3);
  const res5 = await SorttotaltimeRF(res4);
}

async function All(){
  const res1 = await rungroup();
  const res2 = await runAll(res1);
  const res3 = await runAllTime(res2);
  const res4 = await displaycountRF(res3);
}

document.getElementById('output').onclick = function(){//CSV出力用ﾌﾟﾛｸﾞﾗﾑ(回数順)
  var key = [];
  var keydata = [];
  var COUNTdatacsv = [];
  var COUNTdataCSV = [];
  keydata = ['順位','アラームの内容','停止回数','停止時間'];
  for(var i=0; i<displaycount.length; i++){
    COUNTdatacsv[i] = [i+1, displaycount[i][0], displaycount[i][1], displaycount[i][2]];
  }
  COUNTdataCSV.push(keydata);
  COUNTdataCSV.push(COUNTdatacsv);

  var str = "";
  for(var i = 0; i<COUNTdataCSV[0].length; i++){
      if(i==COUNTdataCSV[0].length-1){
          str += COUNTdataCSV[0][i]+"\n";
      }else{
          str += COUNTdataCSV[0][i]+",";
      }
  }
  
  for(var i=0; i<COUNTdataCSV[1].length; i++){
    for(var j=0; j<COUNTdataCSV[1][0].length; j++){
          if(j==COUNTdataCSV[1][0].length-1){
              str += COUNTdataCSV[1][i][j]+"\n";
          }else{
              str += COUNTdataCSV[1][i][j]+",";
          }
      }
  }

  var link = document.createElement('a');
  var bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  var blob =new Blob([bom,str],{type:"text/csv"}); //配列に上記の文字列(str)を設定
  var link =document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download ="tempdate.csv";
  link.click();
}

/*
document.getElementById('output').onclick = function(){//CSV出力用ﾌﾟﾛｸﾞﾗﾑ(時間順)
  var key = [];
  var keydata = [];
  var TIMEdatacsv = [];
  var TIMEdataCSV = [];
  keydata = ['順位','アラームの内容','停止回数','停止時間'];
  for(var i=0; i<displaytime.length; i++){
    TIMEdatacsv[i] = [i+1, displaytime[i][0], displaytime[i][1], displaytime[i][2]];
  }
  TIMEdataCSV.push(keydata);
  TIMEdataCSV.push(TIMEdatacsv);

  var str = "";
  for(var i = 0; i<TIMEdataCSV[0].length; i++){
      if(i==TIMEdataCSV[0].length-1){
          str += TIMEdataCSV[0][i]+"\n";
      }else{
          str += TIMEdataCSV[0][i]+",";
      }
  }
  
  for(var i=0; i<TIMEdataCSV[1].length; i++){
      for(var j=0; j<TIMEdataCSV[1][0].length; j++){
          if(j==TIMEdataCSV[1][0].length-1){
              str += TIMEdataCSV[1][i][j]+"\n";
          }else{
              str += TIMEdataCSV[1][i][j]+",";
          }
      }
  }

  var link = document.createElement('a');
  var bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  var blob =new Blob([bom,str],{type:"text/csv"}); //配列に上記の文字列(str)を設定
  var link =document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download ="tempdate.csv";
  link.click();
}
*/

