

/*document.getElementById("inputymd-7day").value =year7+'-'+month7+'-'+date7;
document.getElementById("inputymd").value =year+'-'+month+'-'+date;
document.getElementById("inputhms").value =hour7+':'+min7+':'+sec7;
document.getElementById("inputhms1").value =hour+':'+min+':'+sec;*/


document.getElementById("開始日").value =year7+'-'+month7+'-'+date7;
document.getElementById("終了日").value =year+'-'+month+'-'+date;
document.getElementById("開始時刻").value =hour7+':'+min7+':'+sec7;
document.getElementById("終了時刻").value =hour+':'+min+':'+sec;

document.getElementById('reload').onclick = function(){//ページ上の更新ボタンを押すと指定した期間のデータを取得する。
    ymdlate = document.getElementById("開始日").value;
    ymdlateSP = ymdlate.split('-');
    hmslate = document.getElementById("開始時刻").value;
    hmslateSP = hmslate.split(':');
    ymdnow = document.getElementById("終了日").value;
    ymdnowSP = ymdnow.split('-');
    hmsnow = document.getElementById("終了時刻").value;
    hmsnowSP = hmsnow.split(':');    

    beforetime = ymdlateSP[0]+'-'+ymdlateSP[1]+'-'+ymdlateSP[2]+'T'+hmslateSP[0]+':'+hmslateSP[1]+':'+hmslateSP[2]+'Z';
    realtime = ymdnowSP[0]+'-'+ymdnowSP[1]+'-'+ymdnowSP[2]+'T'+hmsnowSP[0]+':'+hmsnowSP[1]+':'+hmsnowSP[2]+'Z';
    Alldata=[];
    console.log(beforetime);
    console.log(realtime);
    rungroup();
    runAll();
    runAllTime();
}

document.getElementById('output').onclick = function(){//CSV出力用ﾌﾟﾛｸﾞﾗﾑ
    var key = [];
    var keydata = [];
    var Alldatacsv = [];
    var AlldataCSV = [];
    key = Object.keys(Alldata[0]);
    keydata = [key[0],key[1],key[3],key[5],key[6]];
    for(var i=0; i<Alldata.length; i++){
        Alldatacsv[i] = [Alldata[i][keydata[0]],Alldata[i][keydata[1]],Alldata[i][keydata[2]],Alldata[i][keydata[3]],Alldata[i][keydata[4]]];
    }
    AlldataCSV.push(keydata);
    AlldataCSV.push(Alldatacsv);

    var str = "";
    for(var i = 0; i<AlldataCSV[0].length; i++){
        if(i==AlldataCSV[0].length-1){
            str += AlldataCSV[0][i]+"\n";
        }else{
            str += AlldataCSV[0][i]+",";
        }
    }
    
    for(var i=0; i<AlldataCSV[1].length; i++){
        for(var j=0; j<AlldataCSV[1][0].length; j++){
            if(j==AlldataCSV[1][0].length-1){
                str += AlldataCSV[1][i][j]+"\n";
            }else{
                str += AlldataCSV[1][i][j]+",";
            }
        }
    }
    var link = document.createElement('a');
    var bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
    var blob =new Blob([bom,str],{type:"text/csv"}); //配列に上記の文字列(str)を設定
    var link =document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download ="tempdate.csv";
    link.click();
}

document.getElementById('pagejump').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump1').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump1");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump2').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump2");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump3').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump3");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump4').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump4");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump5').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump5");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump6').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump6");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump7').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump7");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump8').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump8");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

document.getElementById('pagejump9').onclick = function(){//サブ画面表示用
    var div = document.getElementById("pagejump9");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    window.location.href='index1.html?name=' + encodeURIComponent(tabletext);
}

All();

async function runAllTime(){
    const res1 = await makealarmdataRF();
    const res2 = await SearchalarmRF(res1);
    const res3 = await makeAlaemtimeRF(res2);
    const res4 = await TotaltimeRF(res3);
    const res5 = await SorttotaltimeRF(res4);
}

async function All(){
    const res1 = await rungroup();
    const res2 = await runAll(res1);
    const res3 = await runAllTime(res2);
    const res4 = await separatedisplay(res3);
}

async function rungroup(){//グループの読みだしと表示
    const res1 = await groupRF();
    const res2 = await groupinput(res1);
    console.log(group);
  }

  async function runAll(){//すべてのﾌﾟﾛｸﾞﾗﾑを実行する
    const res1 = await Load();
    const res2 = await separatedata1000(res1);
    const res3 = await equipmentRF(res2);
    const res4 = await machineAlarmRF(res3);
    const res5 = await subAlarmdataRF(res4);
    const res6 = await AlarmdataRF(res5);
    const res7 = await CountdataRF(res6);
    const res8 = await SortdataRF(res7);
    const res9 = await hide1(res8);       
}

