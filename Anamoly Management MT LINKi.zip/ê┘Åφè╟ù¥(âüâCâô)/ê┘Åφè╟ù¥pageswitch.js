//異常管理
/*let urlA = '192.168.1.100:3000';//IPアドレス+ポート番号*/
//ここから更新時1回目のみスキャン(読み込み量を減らすため。)

const pageNumbers = (total, max, current) => {
  const half = Math.floor(max / 2);
  let to = max;
  
  if(current + half >= total) {
    to = total;
  } else if(current > half) {
    to = current + half ;
  }
  
  let from = Math.max(to - max, 0);

  return Array.from({length: Math.min(total, max)}, (_, i) => (i + 1) + from);
}

function PaginationButton(totalPages, maxPagesVisible = 5, currentPage = 1) {
  let pages = pageNumbers(totalPages, maxPagesVisible, currentPage);
  let currentPageBtn = null;
  const buttons = new Map();
  const disabled = {
    start: () => pages[0] === 1,
    prev: () => currentPage === 1 || currentPage > totalPages,
    end: () => pages.slice(-1)[0] === totalPages,
    next: () => currentPage >= totalPages
  }
  const frag = document.createDocumentFragment();
  const paginationButtonContainer = document.createElement('div');
  paginationButtonContainer.className = 'pagination-buttons';
  
  const createAndSetupButton = (label = '', cls = '', disabled = false, handleClick) => {
    const buttonElement = document.createElement('button');
    buttonElement.textContent = label;
    buttonElement.className = `page-btn ${cls}`;
    buttonElement.disabled = disabled;
    buttonElement.addEventListener('click', e => {
      handleClick(e);
      this.update();
      paginationButtonContainer.value = currentPage;
      paginationButtonContainer.dispatchEvent(new CustomEvent('change', {detail: {currentPageBtn}}));
    });
    
    return buttonElement;
  }
  
  const onPageButtonClick = e => currentPage = Number(e.currentTarget.textContent);
  
  const onPageButtonUpdate = index => (btn) => {
    btn.textContent = pages[index];
    
    if(pages[index] === currentPage) {
      currentPageBtn.classList.remove('active');
      btn.classList.add('active');
      currentPageBtn = btn;
      currentPageBtn.focus();
    }
  };
  
  buttons.set(
    createAndSetupButton('<<', 'start-page', disabled.start(), () => currentPage = 1),
    (btn) => btn.disabled = disabled.start()
  )
  
  buttons.set(
    createAndSetupButton('<', 'prev-page', disabled.prev(), () => currentPage -= 1),
    (btn) => btn.disabled = disabled.prev()
  )
  
  pages.map((pageNumber, index) => {
    const isCurrentPage = currentPage === pageNumber;
    const button = createAndSetupButton(
      pageNumber, isCurrentPage ? 'active' : '', false, onPageButtonClick
    );
    
    if(isCurrentPage) {
      currentPageBtn = button;
    }
    
    buttons.set(button, onPageButtonUpdate(index));
  });
  
  buttons.set(
    createAndSetupButton('>', 'next-page', disabled.next(), () => currentPage += 1),
    (btn) => btn.disabled = disabled.next()
  )
  
  buttons.set(
    createAndSetupButton('>>', 'end-page', disabled.end(), () => currentPage = totalPages),
    (btn) => btn.disabled = disabled.end()
  )
  
  buttons.forEach((_, btn) => frag.appendChild(btn));
  paginationButtonContainer.appendChild(frag);
  
  this.render = (container = document.body) => {
    container.appendChild(paginationButtonContainer);
  }
  
  this.update = (newPageNumber = currentPage) => {
    currentPage = newPageNumber;
    pages = pageNumbers(totalPages, maxPagesVisible, currentPage);
    buttons.forEach((updateButton, btn) => updateButton(btn));
  }
  
  this.onChange = (handler) => {
    paginationButtonContainer.addEventListener('change', handler);
  }
}
// Create the paginationButtons instance
let paginationButtons;

// Function to handle home1-->hide1 selection
function hide1() {
  // Remove existing pagination buttons if any
  const paginationContainer = document.getElementById('pagination-container');
  paginationContainer.innerHTML = '';

  // Initialize paginationButtons with parameters for home1-->hide1
  paginationButtons = new PaginationButton(3, 3);

  // Render paginationButtons
  paginationButtons.render(paginationContainer);

  // Handle change event
  paginationButtons.onChange(e => {
    console.log('-- changed', e.target.value);
  });
}

// Function to handle home2-->hide2 selection
function hide2() {
  // Remove existing pagination buttons if any
  const paginationContainer = document.getElementById('pagination-container');
  paginationContainer.innerHTML = '';

  // Initialize paginationButtons with parameters for home2-->hide2
  paginationButtons = new PaginationButton(1, 1);

  // Render paginationButtons
  paginationButtons.render(paginationContainer);

  // Handle change event
  paginationButtons.onChange(e => {
    console.log('-- changed', e.target.value);
  });
}

function onPageLoad() {
  // Call home1()-->hide1 function to display the pagination buttons for home1-->hide1
  hide1();
}

// Attach onload event handler to the body tag
document.body.onload = onPageLoad;

var activepageNo = [];

async function paginationNo(){
activepageNo = await pagebtnmake();
console.log(activepageNo);
return activepageNo;
}

async function pagination(){
console.log(activepageNo);
const paginationButtons = new PaginationButton(activepageNo[0][0],activepageNo[1][0]);
paginationButtons.render();

paginationButtons.onChange(e => {
  console.log('-- changed', e.target.value);
  changePage(e.target.value);
});
}

/*async function paginationupdate(){
  const paginationButtons = new PaginationButton(activepageNo[0][1],activepageNo[1][1]);
  paginationButtons.update();

  paginationButtons.onChange(e => {
    console.log('-- changed', e.target.value);
    changePage(e.target.value);
  });
}
*/

async function runpagination(){//グループの読みだしと表示
  const res1 = await paginationNo();
  const res2 = await pagination(res1);
}

runpagination();




/*let x = document.getElementsByClassName("page-btn active");
let page-btn active = 1
if (page-btn active == 1);



<!DOCTYPE html>
<html>
<body>


<style type="text/css">
#AccessLevel1Hide {display: none; }
#AccessLevel1Show {display: block; }
#AccessLevel0Hide {display: none; }
#AccessLevel0Show {display: block; }
</style>


<script type="text/javascript">
var AccessLevel = (1);

if (AccessLevel == 1){
   document.getElementById('AccessLevel1Hide').id="AccessLevel1Show";
}else if (AccessLevel == 0){
   document.getElementById('AccessLevel0Hide').id="AccessLevel0Show";
}else {document.write("ERROR");
}

var Currentpage = (1);

if (Currentpage == 1){
	document.getElementById('currentpage1').id="currentpage1";
    }else if (Currentpage == 2){
    document.getElementById('currentpage2').id="currentpage2";
    }else {Currentpage == 3){
    document.getElementById('currentpage3').id="currentpage3";
    

<p> rggdg </p>

<div id="AccessLevel1Hide">
Access Level 1 message.
</div>

<div id="AccessLevel0Hide">
Access Level 0 message.
</div>


</body>
</html>
*/
