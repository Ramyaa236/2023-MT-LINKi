var Alldata =[];//すべてのアラームデータ
var group = [];//グループの取得
var equipments = [];////各グループに何種類の機械があるか
var machineAlarm = [];//機番ごとに分けたデータ
var subAlarmdata = [];//message、numberのみ
var Alarmdata = [];//machineName、message、numberのみ
var countdata = [];//アラームの回数を格納する。
var number = 1000;//データを1000個ずつで分割する
var separesult = [];//分割されたデータを格納する
let urlA = '192.168.1.203:3000';
var count = {};//メッセージの回数を数える
var Alarmkinds = [];
var Alarmkindsdata = [];
var Alarmtime = [];
var totaltime = [];
var total = 0;

var a = [];
var b = [];
var layout = [];
var listdata = [];

var separecountdata =[];
var separetotaltime =[];
var separeequipments = [];

//更新ボタンを押したときの期間(年月日時分秒)を格納する
var ymdlate;
var ymdlateSP;
var hmslate;
var hmslateSP;
var ymdnow;
var ymdnowSP;
var hmsnow;
var hmsnowSP;

var n = 365;//現在時刻から何日前のデータを取得するかを決める変数(デフォルトは1年分)；
var m = 9;//協定世界時からの時差を決める変数(日本は+9時間)

let day = new Date();//日付データ取得
day.setUTCHours(day.getUTCHours()+m);
var year = day.getUTCFullYear();
var month = ('0'+(day.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date = ('0'+day.getUTCDate()).slice(-2);
var hour = ('0'+(day.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min = ('0'+day.getUTCMinutes()).slice(-2);
var sec = ('0'+day.getSeconds()).slice(-2);

let dayuni = new Date();//世界標準時を取得
var yearuni = dayuni.getUTCFullYear();
var monthuni = ('0'+(dayuni.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var dateuni = ('0'+dayuni.getUTCDate()).slice(-2);
var houruni = ('0'+(dayuni.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var minuni = ('0'+dayuni.getUTCMinutes()).slice(-2);
var secuni = ('0'+dayuni.getSeconds()).slice(-2);


let day2 = new Date();//n日前の日付データ取得
day2.setUTCDate(day2.getUTCDate()-n);
day2.setUTCHours(day2.getUTCHours()+m);//日本の協定世界時からの時差は+9時間
var year7 = day2.getUTCFullYear();
var month7 = ('0'+(day2.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date7 = ('0'+day2.getUTCDate()).slice(-2);
var hour7 = ('0'+(day2.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min7 = ('0'+day2.getUTCMinutes()).slice(-2);
var sec7 = ('0'+day2.getSeconds()).slice(-2);

let day2uni = new Date();//n日前の日付データ取得(世界標準時)
day2uni.setUTCDate(day2uni.getUTCDate()-n);
var year7uni = day2uni.getUTCFullYear();
var month7uni = ('0'+(day2uni.getUTCMonth()+1)).slice(-2);//右から2文字で区切る
var date7uni = ('0'+day2uni.getUTCDate()).slice(-2);
var hour7uni = ('0'+(day2uni.getUTCHours())).slice(-2);//日本の協定世界時からの時差は+9時間
var min7uni = ('0'+day2uni.getUTCMinutes()).slice(-2);
var sec7uni = ('0'+day2uni.getSeconds()).slice(-2);

var realtimea = yearuni+'-'+monthuni+'-'+dateuni+'T'+houruni+':'+minuni+':'+secuni+'Z';
var beforetimea = year7uni+'-'+month7uni+'-'+date7uni+'T'+hour7uni+':'+min7uni+':'+sec7uni+'Z';
var realtime = year+'-'+month+'-'+date+'T'+hour+':'+min+':'+sec+'Z';
var beforetime = year7+'-'+month7+'-'+date7+'T'+hour7+':'+min7+':'+sec7+'Z';
console.log(realtime);
console.log(beforetime);
console.log(realtimea);
console.log(beforetimea);


async function groupRF (){//グループの種類を調べる
	const response = await fetch('http://'+urlA+'/api/v1/groups');
	const data = await response.json(response);
	group = data;
	return group;
}

/*fetch('http://192.168.1.203:3000/api/v1/equipment/alarm-logs')
.then((response) =>{
return response.json();
})
.then((data)=>{
    return array = data;
    
});*/

async function Load(){//すべてのアラームデータを呼び出す
	const response = await fetch('http://'+urlA+'/api/v1/equipment/alarm-logs?from='+beforetime+'&to='+realtime+'&type=OPR');
	const data = await response.json(response);
	Alldata = data;
	return Alldata;
}
    

/*var random=(Math.random());//読み取れたデータの数(本プログラムでは乱数にしている)

random=(Math.floor(random * 10000));*/

/*function getRandom() {//読み取ったデータをarray[]に格納する(本プログラムでは乱数だが、実際のデータは配列)
    for(var i=0; i<random; i++){
    array[i]=[];
    a=0;
    var a=(Math.random());
    a = Math.floor(a * 100);
    array[i] = a; 
    }
}*/

async function separatedata1000(){//読み取ったデータを1000ずつに分割する
    const length = Math.ceil(Alldata.length / number);
    separesult = new Array(length).fill().map((_, i) => 
    Alldata.slice(i * number, (i + 1) * number));
    console.log(separesult);
}//separesult:1000個ずつに分割したデータ


async function equipmentRF(){//各グループに何種類の機械があるかを調べる
    for(var i=0; i<group.length; i++){
        const response = await fetch('http://'+urlA+'/api/v1/groups/'+group[i]['name']+'/equipment');
        const data = await response.json(response);
        equipments[i] = data;
    }
    return equipments;
}

async function machineAlarmRF(){//すべてのアラームデータ機番ごとにデータを分けて呼び出す
    for(var i=0; i<equipments.length; i++){
        machineAlarm[i] = [];
        for(var j=0; j<equipments[i].length; j++){
            machineAlarm[i][j] = [];
            l=0;
            for(var k=0; k<Alldata.length; k++){
                if(equipments[i][j]['name'] == Alldata[k]['equipmentName']){
                    machineAlarm[i][j][l]=Alldata[k];
                    l=l+1;
                }
            }
        }
    }    
    console.log(machineAlarm);
    return machineAlarm;
}

async function subAlarmdataRF(){//機番ごとに取得したデータをmessage、numberのみにして格納する
    for(var i=0; i<machineAlarm.length; i++){
        subAlarmdata[i] = [];
        for(var j=0; j<machineAlarm[i].length; j++){
            subAlarmdata[i][j]=[];
            for(var k=0; k<machineAlarm[i][j].length; k++){
            subAlarmdata[i][j][k]={message:machineAlarm[i][j][k]["message"],number:machineAlarm[i][j][k]["number"]};
            }
            var result = subAlarmdata[i][j].filter((message) => {
                return (message.message != '');
                });
            subAlarmdata[i][j] = result        
        }
    }
}

async function AlarmdataRF(){//機番ごとに取得したデータをmachineName、message、numberのみにして格納する
    for(var i=0; i<machineAlarm.length; i++){
        Alarmdata[i] = [];
        for(var j=0; j<machineAlarm[i].length; j++){
            Alarmdata[i][j]=[];
            for(var k=0; k<machineAlarm[i][j].length; k++){
                if(machineAlarm[i][j][k]["message"] == '' && machineAlarm[i][j][k]["number"] != 0){//messageの中身が「''」だった場合、numberを元にmessageを補完する。尚、messageの中身が「''」でnummberが0の時は無視する
                    var subAlarmdata_find = subAlarmdata[i][j].find(function(value) {
                        return value.number == machineAlarm[i][j][k]["number"];
                    })
                    Alarmdata[i][j][k]={machineName:machineAlarm[i][j][k]["machineName"],message:subAlarmdata_find["message"],number:machineAlarm[i][j][k]["number"]};
                }else{
                    Alarmdata[i][j][k]={machineName:machineAlarm[i][j][k]["machineName"],message:machineAlarm[i][j][k]["message"],number:machineAlarm[i][j][k]["number"]};
                } 
            }
        }
    }
}


async function CountdataRF(){//アラームの回数を数える
    for(var i=0; i<Alarmdata.length; i++){
        countdata[i] = [];
        for(var j=0; j<Alarmdata[i].length; j++){
            countdata[i][j] = [];
            for(var k=0; k<Alarmdata[i][j].length; k++){           
                var elm = Alarmdata[i][j][k]['message'];
                count[elm] = (count[elm] || 0) + 1;
            }
            var count_keys = Object.keys(count);
            var count_values = Object.values(count);
            for(var l=0; l<count_keys.length; l++){
                countdata[i][j][l]=[count_keys[l],count_values[l]];
            }
                count = [];
        }
    }
}

async function SortdataRF(){//アラームの回数が多い順に並び変える
    for(var i=0; i<Alarmdata.length; i++){
        for(var j=0; j<Alarmdata[i].length; j++){
            for(var k=0; k<countdata[i][j].length; k++){           
                if(countdata[i][j].length !== ""){//countdataの中身が空だった場合にエラーが出ないようにするための対策
                    countdata[i][j].sort(function (a,b){
                        return b[1] - a[1];
                    });
                }
        }
    }
}
console.log(countdata);
}

function hide1() {//表示するデータの作成。(本社工場)
    //paginationupdate();
    for(var i=0; i<equipments[0].length; i++){
        a[i] = equipments[0][i]['name'];//機械の名称
    }

    for(var i=0; i<equipments[0].length; i++){
        b[i] = [];
        for(var j=0; j<countdata[0][i].length; j++){  
            b[i][j]=countdata[0][i][j][0];//異常のデータ
        }
    }
  document.getElementById("nowinput").innerHTML = listdata[0];
  document.getElementById("nowdisplay").innerHTML = listdata[2];
  input();
  }

function hide2() {//表示するデータの作成。(北工場)
    //paginationupdate();
    a=[];
    b=[];
    for(var i=0; i<10; i++){
        if(i>4){
            a[i] = 0;
        }else{
            a[i] = equipments[1][i]['name'];
        }

    }

    for(var i=0; i<10; i++){
        b[i] = [];
        for(var j=0; j<5; j++){
            if(i>4){
                b[i][j] = 0;
            }else{
                b[i][j]=countdata[1][i][j][0];
            }
        }
    }
    document.getElementById("nowinput").innerHTML = listdata[1];
    document.getElementById("nowdisplay").innerHTML = listdata[2];      
  input();
  }

function groupinput(){//グループの表示を行う
    listdata[0] = group[0]['displayName'];
    listdata[1] = group[1]['displayName'];
    listdata[2] = '回数'
    listdata[3] = '停止時間'
    document.getElementById("input01").innerHTML = listdata[0];
    document.getElementById("input02").innerHTML = listdata[1];
}

function input(){//ランキングのデータを表示する
    document.getElementById("inputa").innerHTML = a[0];
    document.getElementById("inputb").innerHTML = a[1];
    document.getElementById("inputc").innerHTML = a[2];
    document.getElementById("inputd").innerHTML = a[3];
    document.getElementById("inpute").innerHTML = a[4];
    document.getElementById("inputf").innerHTML = a[5];
    document.getElementById("inputg").innerHTML = a[6];
    document.getElementById("inputh").innerHTML = a[7];
    document.getElementById("inputi").innerHTML = a[8];
    document.getElementById("inputj").innerHTML = a[9];
    document.getElementById("input1").innerHTML = b[0][0];
    document.getElementById("input2").innerHTML = b[0][1];
    document.getElementById("input3").innerHTML = b[0][2];
    document.getElementById("input4").innerHTML = b[0][3];
    document.getElementById("input5").innerHTML = b[0][4];
    document.getElementById("input6").innerHTML = b[1][0];
    document.getElementById("input7").innerHTML = b[1][1];
    document.getElementById("input8").innerHTML = b[1][2];
    document.getElementById("input9").innerHTML = b[1][3];
    document.getElementById("input10").innerHTML = b[1][4];
    document.getElementById("input11").innerHTML = b[2][0];
    document.getElementById("input12").innerHTML = b[2][1];
    document.getElementById("input13").innerHTML = b[2][2];
    document.getElementById("input14").innerHTML = b[2][3];
    document.getElementById("input15").innerHTML = b[2][4];
    document.getElementById("input16").innerHTML = b[3][0];
    document.getElementById("input17").innerHTML = b[3][1];
    document.getElementById("input18").innerHTML = b[3][2];
    document.getElementById("input19").innerHTML = b[3][3];
    document.getElementById("input20").innerHTML = b[3][4];
    document.getElementById("input21").innerHTML = b[4][0];
    document.getElementById("input22").innerHTML = b[4][1];
    document.getElementById("input23").innerHTML = b[4][2];
    document.getElementById("input24").innerHTML = b[4][3];
    document.getElementById("input25").innerHTML = b[4][4];
    document.getElementById("input26").innerHTML = b[5][0];
    document.getElementById("input27").innerHTML = b[5][1];
    document.getElementById("input28").innerHTML = b[5][2];
    document.getElementById("input29").innerHTML = b[5][3];
    document.getElementById("input30").innerHTML = b[5][4];
    document.getElementById("input31").innerHTML = b[6][0];
    document.getElementById("input32").innerHTML = b[6][1];
    document.getElementById("input33").innerHTML = b[6][2];
    document.getElementById("input34").innerHTML = b[6][3];
    document.getElementById("input35").innerHTML = b[6][4];
    document.getElementById("input36").innerHTML = b[7][0];
    document.getElementById("input37").innerHTML = b[7][1];
    document.getElementById("input38").innerHTML = b[7][2];
    document.getElementById("input39").innerHTML = b[7][3];
    document.getElementById("input40").innerHTML = b[7][4];
    document.getElementById("input41").innerHTML = b[8][0];
    document.getElementById("input42").innerHTML = b[8][1];
    document.getElementById("input43").innerHTML = b[8][2];
    document.getElementById("input44").innerHTML = b[8][3];
    document.getElementById("input45").innerHTML = b[8][4];
    document.getElementById("input46").innerHTML = b[9][0];
    document.getElementById("input47").innerHTML = b[9][1];
    document.getElementById("input48").innerHTML = b[9][2];
    document.getElementById("input49").innerHTML = b[9][3];
    document.getElementById("input50").innerHTML = b[9][4];
  }



/*
  async function runAll(){//すべてのﾌﾟﾛｸﾞﾗﾑを実行する
    const res1 = await Load();
    const res2 = await separatedata1000(res1);
    const res3 = await equipmentRF(res2);
    pagebtnmake()
    const res4 = await machineAlarmRF(res3);
    const res5 = await subAlarmdataRF(res4);
    const res6 = await AlarmdataRF(res5);
    const res7 = await CountdataRF(res6);
    const res8 = await SortdataRF(res7);
    const res9 = await hide1(res8);       
}
*/

/*document.getElementById('reload').onclick = function(){
    ymdlate = document.getElementById("inputymd-7day").value;
    ymdlateSP = ymdlate.split('-');
    hmslate = document.getElementById("inputhms").value;
    hmslateSP = hmslate.split(':');
    ymdnow = document.getElementById("inputymd").value;
    ymdnowSP = ymdnow.split('-');
    hmsnow = document.getElementById("inputhms1").value;
    hmsnowSP = hmsnow.split(':');    

    var beforetime = ymdlateSP[0]+'-'+ymdlateSP[1]+'-'+ymdlateSP[2]+'T'+hmslateSP[0]+':'+hmslateSP[1]+':'+hmslateSP[2]+'Z';
    var realtime = ymdnowSP[0]+'-'+ymdnowSP[1]+'-'+ymdnowSP[2]+'T'+hmsnowSP[0]+':'+hmsnowSP[1]+':'+hmsnowSP[2]+'Z';
    console.log(beforetime);
    console.log(realtime);
    rungroup();
    runAll();
}*/



/*
var total = 0;
    for(var j=0; j<machineAlarm[0].length; j++){
        for(var k=0; k<machineAlarm[0][0].length; k++){
            if(machineAlarm[0][0][k]['end'] == null){
                var s = 0;
                total = total + s;
            }else{
            var starttime = Date.parse(machineAlarm[0][0][k]['start']);
            var endtime = Date.parse(machineAlarm[0][0][k]['end']);
            var ms = endtime - starttime;
            var s = ms/1000;
            total = total + s;
        }
        //total=0
    }
}
*/

async function makealarmdataRF(){
for(var i=0; i<machineAlarm.length; i++){//各機番ごとのアラームデータのみの配列を作る
    Alarmkinds[i] = [];
    for(var j=0; j<machineAlarm[i].length; j++){
        Alarmkinds[i][j] = [];
        for(var k=0; k<machineAlarm[i][j].length; k++){
            Alarmkinds[i][j][k] = machineAlarm[i][j][k]['message'];
        }
    }
}
}

async function SearchalarmRF(){
for(var i=0; i<machineAlarm.length; i++){//各機番ごとのアラームの種類を調べる
    Alarmkindsdata[i] = [];
    for(var j=0; j<machineAlarm[i].length; j++){
        Alarmkindsdata[i][j] = Alarmkinds[i][j].filter(function (x, i, self){
            return self.indexOf(x) === i;
        });
    }
}
}

async function makeAlaemtimeRF(){//各機番ごとのアラームデータをまとめる
for(var i=0; i<machineAlarm.length; i++){
    Alarmtime[i] = [];
    for(var j=0; j<machineAlarm[i].length; j++){
        Alarmtime[i][j] = [];
        for(var k=0; k<Alarmkindsdata[i][j].length; k++){
            Alarmtime[i][j][k] = [];
            m=0;
            for(var l=0; l<machineAlarm[i][j].length; l++){
                if(Alarmkindsdata[i][j][k] == machineAlarm[i][j][l]['message']){
                    Alarmtime[i][j][k][m] = machineAlarm[i][j][l];
                    m=m+1;
                }
            }
        }
    }
    console.log(Alarmtime);
}
}

async function TotaltimeRF(){
for(var i=0; i<Alarmtime.length; i++){//各機番のアラームごとにかかった時間を計算する
    totaltime[i] = [];
    for(var j=0; j<Alarmtime[i].length; j++){
        totaltime[i][j] = [];
        for(var k=0; k<Alarmtime[i][j].length; k++){
            totaltime[i][j][k] = [];
            for(var l=0; l<Alarmtime[i][j][k].length; l++){
                if(Alarmtime[i][j][k][l]['end'] == null){
                    var s = 0;
                    total = total + s;
                }else{
                    var starttime = Date.parse(Alarmtime[i][j][k][l]['start']);
                    var endtime = Date.parse(Alarmtime[i][j][k][l]['end']);
                    var ms = endtime - starttime;
                    var s = ms/1000;
                    total = total + s;
                }
                var Messagetime = Alarmtime[i][j][k][l]['message'];
            }
            totaltime[i][j][k] = [Messagetime,total];
            total = 0;
        }
    }
}
}

async function SorttotaltimeRF(){//アラームの時間が長い順に並び変える
    for(var i=0; i<totaltime.length; i++){
        for(var j=0; j<totaltime[i].length; j++){
            for(var k=0; k<totaltime[i][j].length; k++){           
                if(totaltime[i][j].length !== ""){//countdataの中身が空だった場合にエラーが出ないようにするための対策
                    totaltime[i][j].sort(function (a,b){
                        return b[1] - a[1];
                    });
                }
            }
        }
    }
console.log(totaltime);
}

async function separatedisplay(){//表示用データを10個ずつに分ける(ページ切り替えのため)

    for(var j=0; j<equipments.length; j++){
        const lengthequipments = Math.ceil(equipments[j].length / 10);
        separeequipments[j] = new Array(lengthequipments).fill().map((_, i) => 
        equipments[j].slice(i * 10, (i + 1) * 10));
        console.log(separeequipments);
    }

    for(var j=0; j<countdata.length; j++){
        const lengthcount = Math.ceil(countdata[j].length / 10);
        separecountdata[j] = new Array(lengthcount).fill().map((_, i) => 
        countdata[j].slice(i * 10, (i + 1) * 10));
        console.log(separecountdata);
    }

    for(var j=0; j<totaltime.length; j++){
        const lengthtotal = Math.ceil(totaltime[j].length / 10);
    separetotaltime[j] = new Array(lengthtotal).fill().map((_, i) => 
    totaltime[j].slice(i * 10, (i + 1) * 10));
    console.log(separetotaltime);
    }

}



/*
let currentSection = 0;
let sections = document.querySelectorAll(".section");
let sectionButtons = document.querySelectorAll(".nav > li");
let nextButton = document.querySelector(".next");
let previousButton = document.querySelector(".previous");
for (let i = 0; i < sectionButtons.length; i++) {
    sectionButtons[i].addEventListener("click", function() {
        sections[currentSection].classList.remove("active");
        sectionButtons[currentSection].classList.remove("active");
        sections[currentSection = i].classList.add("active");
        sectionButtons[currentSection].classList.add("active");
        if (i === 0) {
            if (previousButton.className.split(" ").indexOf("disable") < 0) {
                previousButton.classList.add("disable");
            }
        } else {
            if (previousButton.className.split(" ").indexOf("disable") >= 0) {
                previousButton.classList.remove("disable");
            }
        }
        if (i === sectionButtons.length - 1) {
            if (nextButton.className.split(" ").indexOf("disable") < 0) {
                nextButton.classList.add("disable");
            }
        } else {
            if (nextButton.className.split(" ").indexOf("disable") >= 0) {
                nextButton.classList.remove("disable");
            }
        }
    });
}

nextButton.addEventListener("click", function() {
    if (currentSection < sectionButtons.length - 1) {
        sectionButtons[currentSection + 1].click();
    }
});

previousButton.addEventListener("click", function() {
    if (currentSection > 0) {
        sectionButtons[currentSection - 1].click();
    }
});
*/
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
/*function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}*/

function countrank(){//停止回数のデータを表示する
    var div = document.getElementById("Nowinput");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);

    var div = document.getElementsByClassName("page-btn active");
    currentpagenumber = div[0]["innerText"];

    if(tabletext == listdata[0]){//本社工場のデータが表示されている場合
        a=[];
        b=[];
        for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
            a[i] = separeequipments[0][currentpagenumber-1][i]['name'];//機械の名称
        }

        if(separecountdata[0][currentpagenumber-1].length<10){
        for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separecountdata[0][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separecountdata[0][currentpagenumber-1][i][j][0];//異常のデータ
                }
        }
        for(var i=separecountdata[0][currentpagenumber-1].length; i<10; i++){
            b[i] = [];            
            for(var j=0; j<5; j++){  
                    b[i][j]=' ';//異常のデータ
                }
        }
    }else{
        for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separecountdata[0][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separecountdata[0][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
    }      
      input();
    }else if(tabletext == listdata[1]){//北工場のデータが表示されている場合
    a=[];
    b=[];
    for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
        a[i] = separeequipments[1][currentpagenumber-1][i]['name'];//機械の名称
    }

    if(separecountdata[1][currentpagenumber-1].length<10){
        for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separecountdata[1][currentpagenumber-1][i].length; j++){  
                b[i][j]=separecountdata[1][currentpagenumber-1][i][j][0];//異常のデータ
            }
        }
    for(var i=separecountdata[1][currentpagenumber-1].length; i<10; i++){
        b[i] = [];            
        for(var j=0; j<5; j++){  
                b[i][j]=' ';//異常のデータ
            }
        }
    }else{
    for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
        b[i] = [];
        for(var j=0; j<separecountdata[1][currentpagenumber-1][i].length; j++){  
                b[i][j]=separecountdata[1][currentpagenumber-1][i][j][0];//異常のデータ
            }
        }
    }
}
input();
    document.getElementById("nowdisplay").innerHTML = listdata[2];
}

function timerank(){//停止時間のデータを表示する
    var div = document.getElementById("Nowinput");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);

    var div = document.getElementsByClassName("page-btn active");
    currentpagenumber = div[0]["innerText"];

    if(tabletext == listdata[0]){//本社工場のデータが表示されている場合
        a=[];
        b=[];
        for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
            a[i] = separeequipments[0][currentpagenumber-1][i]['name'];//機械の名称
        }

        if(separetotaltime[0][currentpagenumber-1].length<10){
        for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separetotaltime[0][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separetotaltime[0][currentpagenumber-1][i][j][0];//異常のデータ
                }
        }
        for(var i=separetotaltime[0][currentpagenumber-1].length; i<10; i++){
            b[i] = [];            
            for(var j=0; j<5; j++){  
                    b[i][j]=' ';//異常のデータ
                }
        }
    }else{
        for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separetotaltime[0][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separetotaltime[0][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
    }      
      input();
    }else if(tabletext == listdata[1]){//北工場のデータが表示されている場合
    a=[];
    b=[];
    for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
        a[i] = separeequipments[1][currentpagenumber-1][i]['name'];//機械の名称
    }

    if(separetotaltime[1][currentpagenumber-1].length<10){
        for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separetotaltime[1][currentpagenumber-1][i].length; j++){  
                b[i][j]=separetotaltime[1][currentpagenumber-1][i][j][0];//異常のデータ
            }
        }
    for(var i=separetotaltime[1][currentpagenumber-1].length; i<10; i++){
        b[i] = [];            
        for(var j=0; j<5; j++){  
                b[i][j]=' ';//異常のデータ
            }
        }
    }else{
    for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
        b[i] = [];
        for(var j=0; j<separetotaltime[1][currentpagenumber-1][i].length; j++){  
                b[i][j]=separetotaltime[1][currentpagenumber-1][i][j][0];//異常のデータ
            }
        }
    }
}
input();
    document.getElementById("nowdisplay").innerHTML = listdata[3];
}


/*  function hide2() {//表示するデータの作成。(北工場)
    a=[];
    b=[];
    for(var i=0; i<10; i++){
        if(i>4){
            a[i] = 0;
        }else{
            a[i] = equipments[1][i]['name'];
        }

    }

    for(var i=0; i<10; i++){
        b[i] = [];
        for(var j=0; j<5; j++){
            if(i>4){
                b[i][j] = 0;
            }else{
                b[i][j]=countdata[1][i][j][0];
            }
        }
    }  
  input();
  }

  */

function changePage(currentpagenumber){//ページ切り替え時の表示用データ
    console.log(currentpagenumber-1);
    var div = document.getElementById("Nowinput");
    console.log(div);
    var spans = div.getElementsByTagName("span");
    console.log(spans)
    var tabletext=spans[0]["outerText"];
    console.log(tabletext);
    
    console.log(currentpagenumber-1);
    var div1 = document.getElementById("Nowdisplay");
    console.log(div1);
    var spans1 = div1.getElementsByTagName("span");
    console.log(spans1)
    var tabletext1=spans1[0]["outerText"];
    console.log(tabletext1);

    if(tabletext1 == listdata[2]){//表示されているデータが回数のランキングの場合
        if(tabletext == listdata[0]){//本社工場のデータが表示されている場合
            a=[];
            b=[];
            for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
                a[i] = separeequipments[0][currentpagenumber-1][i]['name'];//機械の名称
            }
    
            if(separecountdata[0][currentpagenumber-1].length<10){
            for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separecountdata[0][currentpagenumber-1][i].length; j++){  
                        b[i][j]=separecountdata[0][currentpagenumber-1][i][j][0];//異常のデータ
                    }
            }
            for(var i=separecountdata[0][currentpagenumber-1].length; i<10; i++){
                b[i] = [];            
                for(var j=0; j<5; j++){  
                        b[i][j]=' ';//異常のデータ
                    }
            }
        }else{
            for(var i=0; i<separecountdata[0][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separecountdata[0][currentpagenumber-1][i].length; j++){  
                        b[i][j]=separecountdata[0][currentpagenumber-1][i][j][0];//異常のデータ
                    }
                }
        }      
          input();
        }else if(tabletext == listdata[1]){//北工場のデータが表示されている場合
        a=[];
        b=[];
        for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
            a[i] = separeequipments[1][currentpagenumber-1][i]['name'];//機械の名称
        }
    
        if(separecountdata[1][currentpagenumber-1].length<10){
            for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separecountdata[1][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separecountdata[1][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
        for(var i=separecountdata[1][currentpagenumber-1].length; i<10; i++){
            b[i] = [];            
            for(var j=0; j<5; j++){  
                    b[i][j]=' ';//異常のデータ
                }
            }
        }else{
        for(var i=0; i<separecountdata[1][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separecountdata[1][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separecountdata[1][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
        }
    }
    input();
    }else if(tabletext1 == listdata[3]){//表示されているデータが停止時間のランキングの場合
        if(tabletext == listdata[0]){//本社工場のデータが表示されている場合
            a=[];
            b=[];
            for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
                a[i] = separeequipments[0][currentpagenumber-1][i]['name'];//機械の名称
            }
    
            if(separetotaltime[0][currentpagenumber-1].length<10){
            for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separetotaltime[0][currentpagenumber-1][i].length; j++){  
                        b[i][j]=separetotaltime[0][currentpagenumber-1][i][j][0];//異常のデータ
                    }
            }
            for(var i=separetotaltime[0][currentpagenumber-1].length; i<10; i++){
                b[i] = [];            
                for(var j=0; j<5; j++){  
                        b[i][j]=' ';//異常のデータ
                    }
            }
        }else{
            for(var i=0; i<separetotaltime[0][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separetotaltime[0][currentpagenumber-1][i].length; j++){  
                        b[i][j]=separetotaltime[0][currentpagenumber-1][i][j][0];//異常のデータ
                    }
                }
        }      
          input();
        }else if(tabletext == listdata[1]){//北工場のデータが表示されている場合
        a=[];
        b=[];
        for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
            a[i] = separeequipments[1][currentpagenumber-1][i]['name'];//機械の名称
        }
    
        if(separetotaltime[1][currentpagenumber-1].length<10){
            for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
                b[i] = [];
                for(var j=0; j<separetotaltime[1][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separetotaltime[1][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
        for(var i=separetotaltime[1][currentpagenumber-1].length; i<10; i++){
            b[i] = [];            
            for(var j=0; j<5; j++){  
                    b[i][j]=' ';//異常のデータ
                }
            }
        }else{
        for(var i=0; i<separetotaltime[1][currentpagenumber-1].length; i++){
            b[i] = [];
            for(var j=0; j<separetotaltime[1][currentpagenumber-1][i].length; j++){  
                    b[i][j]=separetotaltime[1][currentpagenumber-1][i][j][0];//異常のデータ
                }
            }
        }
    }
    input();
    }
}

async function pagebtnmake(){
    var a=[];
    var b=[];
    const res1 = await groupRF();
    const res2 = await equipmentRF(res1);
    for(var i=0; i<equipments.length; i++){
      a[i]=Math.ceil(equipments[i].length/10);
      if(a[i] < 3){
        b[i] = a[i];
      }else{
        b[i] = 3;
      }
    }
    console.log([a,b]);
    return [a,b];
    //const paginationButtons = new PaginationButton(3,3);
  }
  
  /*
  console.log(activepageNo);
  var div = document.getElementById("Nowinput");
  var spans = div.getElementsByTagName("span");
  var tabletext=spans[0]["outerText"];
  if(tabletext == listdata[0]){
    const paginationButtons = new PaginationButton(activepageNo[0][0],activepageNo[1][0]);
    paginationButtons.render();
  }else if(tabletext == listdata[1]){
    const paginationButtons = new PaginationButton(activepageNo[0][0],activepageNo[1][0]);
    paginationButtons.render();
  }
  */
